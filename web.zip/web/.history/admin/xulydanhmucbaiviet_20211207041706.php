<?php 
    include('/xampp/htdocs/web/web/db/connect.php');
?>
<?php 
    if(isset($_POST['themdanhmuc'])){
        $tendanhmuc = $_POST['danhmuc'];
        $sql_insert = mysqli_query($mysqli,"INSERT INTO tbl_danhmuc_tin(tendanhmuc) value ('$tendanhmuc')");
    }elseif(isset($_POST['capnhapdanhmuc'])){
        $id_post = $_POST['id_danhmuc'];
        $tendanhmuc = $_POST['danhmuc'];
        $sql_update = mysqli_query($mysqli,"UPDATE tbl_category SET category_name = '$tendanhmuc' WHERE category_id = '$id_post' ");
        header('Location: ./xulydanhmuc.php');
    }
    if(isset($_GET['xoa'])){
        $id = $_GET['xoa'];
        $sql_xoa = mysqli_query($mysqli,"DELETE FROM tbl_category WHERE category_id = '$id'");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh muc</title>
    <link href="../web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" href="xulydonhang.php">Đơn hàng <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="xulydanhmuc.php">Danh mục</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="xulydanhmucbaiviet.php">Danh mục bài viết</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="xulysanpham.php">Sản phẩm</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled" href="xulykhachhang.php">Khách hàng</a>
            </li>
          </ul>
        </div>
      </nav><br></br>
    <div class="container">
        <div class="row">
            <?php 
                  if(isset($_GET['quanly'])=='capnhap'){
                    $id_capnhap = $_GET['id'];
                    $sql_capnhap = mysqli_query($mysqli,"SELECT * FROM tbl_category WHERE category_id = '$id_capnhap'");   
                    $row_capnhap =  mysqli_fetch_array($sql_capnhap);
            ?>
            <div class="col-md-4">
                <h4>Cập nhập danh mục</h4>
                <label for="">Tên danh mục</label>
                <form action="" method="POST">
                    <input type="text" class="form-control" name="danhmuc" value="<?php echo $row_capnhap['tendanhmuc'] ?>"></br>
                    <input type="hidden" class="form-control" name="id_danhmuc" value="<?php echo $row_capnhap['category_id'] ?>">
                    <input type="submit" class="btn btn-defaul" name="capnhapdanhmuc" value="Cập nhập danh mục">
                </form>
            </div>
            <?php
                  }else{
            ?>
             <div class="col-md-4">
                <h4>Thêm danh mục</h4>
                <label for="">Tên danh mục</label>
                <form action="" method="POST">
                    <input type="text" class="form-control" name="danhmuc" placeholder="Tên danh mục"></br>
                    <input type="submit" class="btn btn-defaul" name="themdanhmuc" value="Thêm danh mục">
                </form>
                </div>
            <?php
                  }
            ?>
            <div class="col-md-8">
                <h4>Liệt kê danh mục</h4>
                <?php 
                $sql_select = mysqli_query($mysqli,"SELECT * FROM tbl_category ORDER BY category_id DESC");
                ?>
                <table class="table table-responsive table-bordered">
                    <tr>
                        <th>Thứ tự</th>
                        <th>Tên danh mục</th>
                        <th>Quản lý</th>
                    </tr>
                    <?php 
                    $i = 0;
                        while($row_category = mysqli_fetch_array($sql_select)){
                            $i++;
                    ?>
                    <tr>
                        <td><?php echo $i;?></td>
                        <td><?php echo $row_category['category_name'] ?></td>
                        <td><a href="?xoa=<?php echo $row_category['category_id'] ?>">Xóa</a> || <a href="?quanly=capnhap&id=<?php echo $row_category['category_id'] ?>">Cập nhập</a></td>
                    </tr>
                    <?php 
                    }
                    ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>