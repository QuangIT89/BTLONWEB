<?php 
    session_start();
    if(!isset($_SESSION['dangnhap'])){
        header('Location : index.php');
    }
    if(isset($_GET['login'])){
        $dangxuat = $_GET['login'];
    }else{
        $dangxuat = '';
    }
    if($dangxuat=='dangxuat'){
        unset($_SESSION['dangnhap']);
        header('Location: index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh muc</title>
    <link href="../web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h4>Thêm danh mục</h4>
                <label for="">Tên danh mục</label>
                <input type="text" class="form-control" name="danhmuc" placeholder="Tên danh mục">
            </div>
            <div class="col-md-8">
                <h4>Liệt kê danh mục</h4>
            </div>
        </div>
    </div>
</body>
</html>