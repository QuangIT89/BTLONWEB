<?php 
    include('/xampp/htdocs/web/web/db/connect.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Khách hàng</title>
    <link href="../web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" href="xulydonhang.php">Đơn hàng <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="xulydanhmuc.php">Danh mục</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="xulysanpham.php">Sản phẩm</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled" href="xulykhachhang.php">Khách hàng</a>
            </li>
          </ul>
        </div>
      </nav><br></br>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4>Liệt kê Khách hàng</h4>
                <?php 
                $sql_select_khachhang = mysqli_query($mysqli,"SELECT * FROM tbl_khachhang ORDER BY tbl_khachhang.khachhang_id DESC");
                ?> 
                <table class="table table-responsive table-bordered">
                    <tr>
                        <th>Thứ tự</th>
                        <th>Tên khách hàng</th>
                        <th>Số điện thoại</th>
                        <th>Địa chỉ</th>
                        <th>Email</th>
                        <th>Quản lý</th>
                    </tr>
                    <?php 
                    $i = 0;
                        while($row_donhang = mysqli_fetch_array($sql_select)){
                            $i++;
                    ?> 
                    <tr>
                        <td><?php echo $i;?></td>
                        <td><?php echo $row_donhang['mahang'];?></td>
                        <td><?php
                        if($row_donhang['tinhtrang']==0){
                            echo 'Chưa xử lý';
                        }else{
                            echo 'Đã xử lý';
                        }
                        ?></td>
                        <td><?php echo $row_donhang['name'];?></td>
                        <td><?php echo $row_donhang['ngaythang'] ?></td>
                        <td><?php echo $row_donhang['note'] ?></td>
                        <td><a href="?xoadonhang=<?php echo $row_donhang['mahang'] ?>">Xóa</a> || <a href="?quanly=xemdonhang&mahang=<?php echo $row_donhang['mahang'] ?>">Xem đơn hàng</a></td>
                    </tr>
                    <?php 
                    }
                    ?> 
                </table>
            </div>
        </div>
    </div>
</body>
</html>