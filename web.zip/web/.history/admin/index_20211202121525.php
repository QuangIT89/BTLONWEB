
<?php 
    if(isset($_POST['dangnhap'])){
        $taikhoan = $_POST['taikhoan'];
        $matkhau = $_POST['matkhau'];
        if($taikhoan =='' || $matkhau ==''){
            echo '<p>Hãy nhập tài khoản hoặc mật khẩu</p>';
        }else{
            $sql_select_admin = mysqli_query($mysqli,"SELECT * FROM tbl_admin WHERE eamil = 'taikhoan' AND password = 'matkhau'");
            $count = mysqli_num_rows($sql_select_admin);
            if($count>0){
                header('Location: dashboard.php');
            }else{
                echo '<p>Tài khoản hoặc mật khẩu không chính xác</p>';
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập admin</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
    <h2>Đăng nhập Admin</h2>
    <div class="col-md-6">
        <div class="from-froup">
            <form action="" method="POST">
            <label for="">Tài khoản</label>
            <input type="text" name="taikhoan" class="from-coltrol" placeholder="Nhập Email hoặc Số điện thoại">
            <label for="">Mật khẩu</label>
            <input type="text" name="matkhau" class="from-coltrol" placeholder="Mật khẩu">
            <input type="submit" name="dangnhap" class="btn btn-primary" value="Đăng nhập">
            </form>
        </div>
    </div>
</body>
</html>