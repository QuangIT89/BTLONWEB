<?php 
    include('/xampp/htdocs/web/web/db/connect.php');
?>
<?php 
    if(isset($_POST['thembaiviet'])){
        $tenbaiviet = $_POST['tenbaiviet'];
        $hinhanh = $_FILES['hinhanh']['name'];
        $danhmuc = $_POST['danhmuc'];
        $chitiet = $_POST['chitiet'];
        $mota = $_POST['mota'];
        $path = '../upload/';
        
        $sql_insert_product = mysqli_query($mysqli,"INSERT INTO tbl_baiviet(tenbaiviet,tomta,noidung,danhmuctin_id,baiviet_image) value ('$tenbaiviet','$mota','$chitiet','$danhmuc','$hinhanh')");
        move_uploaded_file($hinhanh_tmp,$path.$hinhanh);
    }elseif(isset($_POST['capnhapbaiviet'])){
        $id_update = $_POST['id_update'];
        $tenbaiviet = $_POST['tenbaiviet'];
        $hinhanh = $_FILES['hinhanh']['name'];
        $hinhanh_tmp = $_FILES['hinhanh']['tmp_name'];
        $danhmuc = $_POST['danhmuc'];
        $chitiet = $_POST['chitiet'];
        $mota = $_POST['mota'];
        $path = '../upload/';
        if($hinhanh == ''){
            $sql_update_image = "UPDATE tb_sanpham SET tenbaiviet ='$tenbaiviet',chitiet ='$chitiet',tomtat ='$mota',danhmuctin_id ='$danhmuc' WHERE baiviet_id= '$id_update'";
        }else{
            move_uploaded_file($hinhanh_tmp,$path.$hinhanh);
            $sql_update_image = "UPDATE tb_sanpham SET sanpham_name ='$tensanpham',sanpham_chitiet ='$chitiet',sanpham_mota ='$mota',sanpham_gia ='$gia',sanpham_giakhuyenmai ='$giakhuyenmai',sanpham_soluong ='$soluong',sanpham_image = '$hinhanh',category_id ='$danhmuc' WHERE sanpham_id= '$id_update'";
        }
        mysqli_query($mysqli,$sql_update_image);
    }
?>
<?php 
    if(isset($_GET['xoa'])){
        $id = $_GET['xoa'];
        $sql_xoa = mysqli_query($mysqli,"DELETE FROM tb_sanpham WHERE sanpham_id = '$id'");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sản phẩm</title>
    <link href="../web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" href="xulydonhang.php">Đơn hàng <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="xulydanhmuc.php">Danh mục</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="xulydanhmucbaiviet.php">Danh mục bài viết</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="xulybaiviet.php">Bài viết</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="xulysanpham.php">Sản phẩm</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled" href="xulykhachhang.php">Khách hàng</a>
            </li>
          </ul>
        </div>
      </nav><br></br>
    <div class="container">
        <div class="row">
             <?php 
                  if(isset($_GET['quanly'])=='capnhap'){
                    $id_capnhap = $_GET['capnhap_id'];
                    $sql_capnhap = mysqli_query($mysqli,"SELECT * FROM tbl_baiviet WHERE baiviet_id = '$id_capnhap'");   
                    $row_capnhap =  mysqli_fetch_array($sql_capnhap);
                    $id_category_1 = $row_capnhap['danhmuctin_id'];
            ?> 
            <div class="col-md-4">
                <h4>Cập nhập bài viết</h4>
                <form action="" method="POST" enctype="multipart/form-data">
                    <label for="">Tên bài viết </label>
                    <input type="text" class="form-control" name="tenbaiviet" value="<?php echo $row_capnhap['tenbaiviet'] ?>"></br>
                    <input type="hidden" class="form-control" name="id_update" value="<?php echo $row_capnhap['baiviet_id'] ?>"></br>
                    <input type="file" class="form-control" name="hinhanh"></br>
                    <img src="../upload/<?php echo$row_capnhap['baiviet_image'] ?>" height="80" width="90" alt=""></br>
                    <label for="">Mô tả</label>
                    <textarea class="form-control" rows="10" name="mota" id=""><?php echo $row_capnhap['tomtat'] ?></textarea></br>
                    <label for="">Chi tiết</label>
                    <textarea class="form-control" rows="10" name="chitiet" id=""><?php echo $row_capnhap['noidung'] ?></textarea></br>
                    <label for="">Danh mục</label>
                    <?php 
                    $sql_danhmuc = mysqli_query($mysqli,"SELECT * FROM tbl_danhmuc_tin ORDER BY danhmuctin_id DESC");
                    ?>
                    <select name="danhmuc" id="">
                        <option value="">------Chọn danh mục------</option>
                        <?php
                        while($row_danhmuc = mysqli_fetch_array($sql_danhmuc)){
                            if($id_category_1 == $row_danhmuc['danhmuctin_id']){
                        ?>
                        <option selected value="<?php echo $row_danhmuc['danhmuctin_id'] ?>"><?php echo $row_danhmuc['tendanhmuc'] ?></option>
                        <?php 
                           }else{
                        ?>
                        <option value="<?php echo $row_danhmuc['category_id'] ?>"><?php echo $row_danhmuc['tendanhmuc'] ?></option>
                        <?php      
                           }
                        }
                        ?>
                    </select></br>
                    <input type="submit" class="btn btn-defaul" name="capnhapbaiviet" value="Cập nhập bài viết">
                </form>
                </div>
             <?php
                  }else{
            ?> 
             <div class="col-md-4">
                <h4>Thêm bài viết</h4>
                <form action="" method="POST" enctype="multipart/form-data">
                    <label for="">Tên sản phẩm</label>
                    <input type="text" class="form-control" name="tenbaiviet" placeholder="Tên bài viết"></br>
                    <label for="">Hình ảnh</label>
                    <input type="file" class="form-control" name="hinhanh" placeholder="Tên sản phẩm"></br>
                    <label for="">Mô tả</label>
                    <textarea class="form-control" name="mota" id=""></textarea></br>
                    <label for="">Chi tiết</label>
                    <textarea class="form-control" name="chitiet" id=""></textarea></br>
                    <label for="">Danh mục</label>
                    <?php 
                    $sql_danhmuc = mysqli_query($mysqli,"SELECT * FROM tbl_danhmuc_tin ORDER BY danhmuctin_id DESC");
                    ?>
                    <select name="danhmuc" id="">
                        <option value="">------Chọn danh mục------</option>
                        <?php
                        while($row_danhmuc = mysqli_fetch_array($sql_danhmuc)){
                        ?>
                        <option value="<?php echo $row_danhmuc['danhmuctin_id'] ?>"><?php echo $row_danhmuc['tendanhmuc'] ?></option>
                        <?php 
                        }
                        ?>
                    </select></br>
                    <input type="submit" class="btn btn-defaul" name="thembaiviet" value="Thêm bài viết">
                </form>
                </div>
           <?php
                  }
            ?> 
            <div class="col-md-8">
                <h4>Liệt kê bài viết</h4>
                <?php 
                $sql_select_bv = mysqli_query($mysqli,"SELECT * FROM tbl_baiviet,tbl_danhmuc_tin WHERE tbl_baiviet.danhmuctin_id = tbl_danhmuc_tin.danhmuctin_id ORDER BY tbl_baiviet.danhmuctin_id DESC");
                ?> 
                <table class="table table-responsive table-bordered">
                    <tr>
                        <th>Thứ tự</th>
                        <th>Tên sản phẩm</th>
                        <th>Hình ảnh</th>
                        <th>Danh mục</th>
                        <th>Quản lý</th>
                    </tr>
                    <?php 
                    $i = 0;
                        while($row_bv = mysqli_fetch_array($sql_select_bv)){
                            $i++;
                    ?> 
                    <tr>
                        <td><?php echo $i ?></td>
                        <td><?php echo $row_bv['tenbaiviet'] ?></td>
                        <td><img src="../upload/<?php echo $row_bv['baiviet_image'] ?>" height="80" width="80" alt=""></td>
                        <td><?php echo $row_bv['tendanhmuc'] ?></td>
                        <td><a href="?xoa=<?php echo $row_bv['danhmuctin_id'] ?>">Xóa</a> || <a href="xulybaiviet.php?quanly=capnhap&capnhap_id=<?php echo $row_bv['danhmuctin_id'] ?>">Cập nhập</a></td>
                    </tr>
                    <?php 
                    }
                    ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>