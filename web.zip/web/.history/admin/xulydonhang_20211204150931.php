<?php 
    include('/xampp/htdocs/web/web/db/connect.php');
?>
<!-- <?php 
    if(isset($_POST['themdanhmuc'])){
        $tendanhmuc = $_POST['danhmuc'];
        $sql_insert = mysqli_query($mysqli,"INSERT INTO tbl_category(category_name) value ('$tendanhmuc')");
    }elseif(isset($_POST['capnhapdanhmuc'])){
        $id_post = $_POST['id_danhmuc'];
        $tendanhmuc = $_POST['danhmuc'];
        $sql_update = mysqli_query($mysqli,"UPDATE tbl_category SET category_name = '$tendanhmuc' WHERE category_id = '$id_post' ");
        header('Location: ./xulydanhmuc.php');
    }
    if(isset($_GET['xoa'])){
        $id = $_GET['xoa'];
        $sql_xoa = mysqli_query($mysqli,"DELETE FROM tbl_category WHERE category_id = '$id'");
    }
?> -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đơn hàng</title>
    <link href="../web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Navbar</a>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" href="xulydonhang.php">Đơn hàng <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="xulydanhmuc.php">Danh mục</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="xulysanpham.php">Sản phẩm</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled" href="#">Khách hàng</a>
            </li>
          </ul>
        </div>
      </nav><br></br>
    <div class="container">
        <div class="row">
             <?php 
                  if(isset($_GET['quanly'])=='xemdonhang'){
                    $mahang = $_GET['mahang'];
                    $sql_chitiet = mysqli_query($mysqli,"SELECT * FROM tbl_donhang,tb_sanpham WHERE tbl_donhang.sanpham_id =tb_sanpham.sanpham_id AND tb_donhang.mahang = '$mahang'");   
                    $row_chitiet =  mysqli_fetch_array($sql_chitiet);
            ?>
            <p>Xem chi tiết đơn hàng</p>
            <table class="table table-responsive table-bordered">
                    <tr>
                        <th>Thứ tự</th>
                        <th>Mã hàng</th>
                        <th>Tên sản phẩm</th>
                        <th>Số lượng</th>
                        <th>Tổng tiền</th>
                        <th>Ngày đặt</th>
                        <th>Quản lý</th>
                    </tr>
                    <?php 
                    $i = 0;
                        while($row_donhang = mysqli_fetch_array($sql_chitiet)){
                            $i++;
                    ?> 
                    <tr>
                        <td><?php echo $i;?></td>
                        <td><?php echo $row_donhang['mahang'];?></td>
                        <td><?php echo $row_donhang['sanpham_name'];?></td>
                        <td><?php echo $row_donhang['soluong']*$row_donhang['sanpham_giakhuyenmai'];?></td>
                        <td><?php echo $row_donhang['ngaythang'] ?></td>
                        <!-- <td><a href="?xoa=<?php echo $row_donhang['donhang_id'] ?>">Xóa</a> || <a href="?quanly=xemdonhang&mahang=<?php echo $row_donhang['mahang'] ?>">Xem đơn hàng</a></td> -->
                    </tr>
                    <?php 
                    }
                    ?> 
                </table>  
            <?php
                  }else{
            ?>
            
               <div class="col-md-7">
                    <p>Đơn hàng</p>
                </div> 
             <?php
                  }
            ?>
            <div class="col-md-5">
                <h4>Liệt kê đơn hàng</h4>
                <?php 
                $sql_select = mysqli_query($mysqli,"SELECT * FROM tb_sanpham,tbl_khachhang,tbl_donhang WHERE tbl_donhang.sanpham_id = tb_sanpham.sanpham_id AND tbl_donhang.khachhang_id=tbl_khachhang.khachhang_id ORDER BY tbl_donhang.donhang_id DESC");
                ?> 
                <table class="table table-responsive table-bordered">
                    <tr>
                        <th>Thứ tự</th>
                        <th>Mã hàng</th>
                        <th>Tên khách hàng</th>
                        <th>Ngày đặt</th>
                        <th>Quản lý</th>
                    </tr>
                    <?php 
                    $i = 0;
                        while($row_donhang = mysqli_fetch_array($sql_select)){
                            $i++;
                    ?> 
                    <tr>
                        <td><?php echo $i;?></td>
                        <td><?php echo $row_donhang['mahang'];?></td>
                        <td><?php echo $row_donhang['name'];?></td>
                        <td><?php echo $row_donhang['ngaythang'] ?></td>
                        <td><a href="?xoa=<?php echo $row_donhang['donhang_id'] ?>">Xóa</a> || <a href="?quanly=xemdonhang&mahang=<?php echo $row_donhang['mahang'] ?>">Xem đơn hàng</a></td>
                    </tr>
                    <?php 
                    }
                    ?> 
                </table>
            </div>
        </div>
    </div>
</body>
</html>